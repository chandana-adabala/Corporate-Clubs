import * as React from 'react';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Link } from 'office-ui-fabric-react/lib/Link';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { TooltipHost } from 'office-ui-fabric-react/lib/Tooltip';


export default class MyToggle extends React.Component<any,{}> {
  public render(): JSX.Element {
    // tslint:disable:jsx-no-lambda
    return (
      <div >
        <Toggle 
          defaultChecked={true}
          label="Enabled and checked"
          onText="On"
          offText="Off"
          onFocus={() => console.log('onFocus called')}
          onBlur={() => console.log('onBlur called')}
          onChange={() =>{ console.log('onBlur called');
                           return this.props.onChange         ;         
        }}
        />
       
      </div>
    );
  }

  private _onChange(ev: React.MouseEvent<HTMLElement>, checked: boolean) {
    console.log('toggle is ' + (checked ? 'checked' : 'not checked'));
  }
}